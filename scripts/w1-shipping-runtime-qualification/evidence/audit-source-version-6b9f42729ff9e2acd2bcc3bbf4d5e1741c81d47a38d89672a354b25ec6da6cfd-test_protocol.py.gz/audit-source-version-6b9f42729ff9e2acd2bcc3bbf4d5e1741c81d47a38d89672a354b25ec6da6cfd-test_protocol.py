import copy,hashlib,pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
import client,protocol
class Gates(unittest.TestCase):
 def test_scientific_precision_and_exact_exclusion(self):
  a=b'{"results":[9007199254740993,1e-99],"diagnostics":{"elapsed_ms":1,"selection_rule":"a"}}'
  b=a.replace(b'"elapsed_ms":1',b'"elapsed_ms":999')
  self.assertEqual(client.canonical(a),client.canonical(b))
  for old,new in [(b'9007199254740993',b'9007199254740992'),(b'1e-99',b'2e-99'),(b'"a"',b'"b"')]:self.assertNotEqual(client.canonical(a),client.canonical(a.replace(old,new)))
  with self.assertRaises(ValueError):client.canonical(b'{"diagnostics":{}}')
 def test_http_headroom_stream_clock_and_completion(self):
  r={'status':200,'stream_complete':True,'server_completion_observed':True,'elapsed_seconds':45,'clock_discontinuity':False}
  self.assertTrue(protocol.complete_request(r))
  for key,value in [('elapsed_seconds',45.0001),('status',504),('stream_complete',False),('server_completion_observed',False),('clock_discontinuity',True)]:
   bad=r|{key:value};self.assertFalse(protocol.complete_request(bad))
 def test_memory_boundaries(self):
  row={'after_probes':{'cgroup_peak_bytes':75,'memory_events':{}}};self.assertTrue(protocol.memory(row,100));row['after_probes']['cgroup_peak_bytes']=76;self.assertFalse(protocol.memory(row,100))
  for key in ['oom','oom_kill','max']:
   row={'after_probes':{'cgroup_peak_bytes':75,'memory_events':{key:1}}};self.assertFalse(protocol.memory(row,100))
 def test_exact_mixed_baselines(self):
  plans={'A-single-0':[{'fixture':'dense-28-W1','operation':'optimize','repeat':i} for i in range(5)],'A-mixed-0':[{'fixture':'dense-28-W1','operation':'two-optimizers','repeat':0}]}
  rows={'A-single-0':[dict(c,plan_index=i) for i,c in enumerate(plans['A-single-0'])]};self.assertTrue(protocol.mixed_guard(plans,rows,'A'))
  for field,value in [('fixture','other-W1'),('operation','evaluate'),('repeat',9)]:
   bad=copy.deepcopy(rows);bad['A-single-0'][0][field]=value
   with self.assertRaises((ValueError,AssertionError)):protocol.mixed_guard(plans,bad,'A')
  with self.assertRaises(ValueError):protocol.mixed_guard(plans,{'A-single-0':rows['A-single-0'][:4]},'A')
 def test_final_tail_cannot_pass_queue_only(self):
  response={'start':'2026-10-05T00:00:30Z','end':'2026-10-05T00:00:31Z'}
  job={'job_id':'j','status':'running','cache_hit':False,'completed_runs':1,'total_runs':64}
  row={'responses':[response],'extra':{'launches':[{'job':job}]}}
  evidence={'errors':[],'drain_barrier_pass':True,'sustained':False,'final_jobs':[job|{'status':'succeeded','started_at':'2026-10-05T00:00:00Z','finished_at':'2026-10-05T00:00:29Z'}]}
  self.assertTrue(protocol.background_failures(row,evidence))
  evidence['final_jobs'][0]['finished_at']='2026-10-05T00:00:32Z';self.assertEqual(protocol.background_failures(row,evidence),[])
  row['extra']['launches'][0]['job']['status']='accepted';self.assertTrue(protocol.background_failures(row,evidence))
if __name__=='__main__':unittest.main()
